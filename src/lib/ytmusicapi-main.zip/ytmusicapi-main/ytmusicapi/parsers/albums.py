from ytmusicapi.helpers import parse_description_runs, to_int
from ytmusicapi.type_alias import JsonDict

from ._utils import *
from .artists import parse_artists_runs
from .songs import parse_like_status, parse_song_runs


def parse_album_header(response: JsonDict) -> JsonDict:
    header = nav(response, HEADER_DETAIL)
    album = {
        "title": nav(header, TITLE_TEXT),
        "type": nav(header, SUBTITLE),
        "thumbnails": nav(header, THUMBNAIL_CROPPED, True),
        "isExplicit": nav(header, SUBTITLE_BADGE_LABEL, True) is not None,
    }

    if "description" in header:
        album["description"] = header["description"]["runs"][0]["text"]

    album_info = parse_song_runs(header["subtitle"]["runs"][2:])
    album.update(album_info)

    if len(header["secondSubtitle"]["runs"]) > 1:
        album["trackCount"] = to_int(header["secondSubtitle"]["runs"][0]["text"])
        album["duration"] = header["secondSubtitle"]["runs"][2]["text"]
    else:
        album["duration"] = header["secondSubtitle"]["runs"][0]["text"]

    # add to library/uploaded
    menu = nav(header, MENU)
    toplevel = menu["topLevelButtons"]
    album["audioPlaylistId"] = nav(toplevel, [0, "buttonRenderer", *NAVIGATION_WATCH_PLAYLIST_ID], True)
    if not album["audioPlaylistId"]:
        album["audioPlaylistId"] = nav(toplevel, [0, "buttonRenderer", *NAVIGATION_PLAYLIST_ID], True)
    service = nav(toplevel, [1, "buttonRenderer", "defaultServiceEndpoint"], True)
    if service:
        album["likeStatus"] = parse_like_status(service)

    return album


def parse_album_header_2024(response: JsonDict) -> JsonDict:
    header = nav(response, [*TWO_COLUMN_RENDERER, *TAB_CONTENT, *SECTION_LIST_ITEM, *RESPONSIVE_HEADER])
    album = {
        "title": nav(header, TITLE_TEXT),
        "type": nav(header, SUBTITLE),
        "thumbnails": nav(header, THUMBNAILS, True),
        "isExplicit": nav(header, SUBTITLE_BADGE_LABEL, True) is not None,
    }
    description, description_runs = parse_description_runs(
        nav(header, ["description", *DESCRIPTION_SHELF, *DESCRIPTION_RUN_LIST], True)
    )
    album["description"] = description
    album["descriptionRuns"] = description_runs

    album_info = parse_song_runs(header["subtitle"]["runs"][2:])
    strapline_runs = nav(header, ["straplineTextOne", "runs"], True)
    album_info["artists"] = parse_artists_runs(strapline_runs) if strapline_runs else None
    album.update(album_info)

    if len(header["secondSubtitle"]["runs"]) > 1:
        album["trackCount"] = to_int(header["secondSubtitle"]["runs"][0]["text"])
        album["duration"] = header["secondSubtitle"]["runs"][2]["text"]
    else:
        album["duration"] = header["secondSubtitle"]["runs"][0]["text"]

    # add to library/uploaded
    buttons = header["buttons"]
    album["audioPlaylistId"] = nav(
        find_object_by_key(buttons, "musicPlayButtonRenderer"),
        ["musicPlayButtonRenderer", "playNavigationEndpoint", *WATCH_PID],
        True,
    )
    # remove this once A/B testing is finished and it is no longer covered
    if album["audioPlaylistId"] is None:
        album["audioPlaylistId"] = nav(
            find_object_by_key(buttons, "musicPlayButtonRenderer"),
            ["musicPlayButtonRenderer", "playNavigationEndpoint", *WATCH_PLAYLIST_ID],
            True,
        )
    service = nav(
        find_object_by_key(buttons, "toggleButtonRenderer"),
        ["toggleButtonRenderer", "defaultServiceEndpoint"],
        True,
    )
    album["likeStatus"] = "INDIFFERENT"
    if service:
        album["likeStatus"] = parse_like_status(service)

    return album


def parse_album_playlistid_if_exists(data: JsonDict | None) -> str | None:
    """the content of the data changes based on whether the user is authenticated or not"""
    return nav(data, WATCH_PID, True) or nav(data, WATCH_PLAYLIST_ID, True) if data else None
