import json
import time
from collections.abc import Callable
from typing import Any
from unittest import mock

import pytest

from ytmusicapi import YTMusic
from ytmusicapi.constants import SUPPORTED_LANGUAGES
from ytmusicapi.enums import ResponseStatus
from ytmusicapi.exceptions import YTMusicGatedError, YTMusicServerError, YTMusicUserError
from ytmusicapi.models.content.enums import PlaylistSortOrder, PlaylistVoteEditOptions, VoteStatus


def create_playlist(yt: YTMusic, *args: Any, **kwargs: Any) -> str:
    """Create a playlist, skipping the test while YTM gates creation for the account."""
    try:
        playlist_id = yt.create_playlist(*args, **kwargs)
    except YTMusicGatedError as e:
        pytest.skip(str(e))

    assert isinstance(playlist_id, str) and playlist_id.startswith("PL"), "Playlist creation failed"
    return playlist_id


def retry_playlist_edit(edit: Callable[[], Any], attempts: int = 8, delay: int = 5) -> Any:
    """Run the first edit of a freshly created playlist.

    YTM rejects these (409 Conflict, or 400 Precondition for collaboration) for up to ~20s
    after creation, until the new playlist has settled server-side.
    """
    for attempt in range(1, attempts + 1):
        try:
            return edit()
        except YTMusicServerError:
            if attempt == attempts:
                raise
            time.sleep(delay)


class TestPlaylists:
    @pytest.mark.parametrize(
        "test_file, playlist_id",
        [
            ("2024_03_get_playlist.json", "PLaZPMsuQNCsWn0iVMtGbaUXO6z-EdZaZm"),
            ("2024_03_get_playlist_public.json", "RDCLAK5uy_lWy02cQBnTVTlwuRauaGKeUDH3L6PXNxI"),
            ("2025_10_get_playlist_collaborative.json", "PLxyTaDz8f5PBc-8kE36gvB-eflhODG2dw"),
            ("2025_12_get_playlist_audio.json", "OLAK5uy_n0x1TMX8DL2eli2g_LysCSg-6Nq5YQa1g"),
            ("2025_01_get_playlist_chart.json", "OLAK5uy_mzYnlaHgFOvLaxqIPnnouEr-idiUn4NIM"),
        ],
    )
    def test_get_playlist(self, yt, test_file, playlist_id, data_path):
        with open(data_path / test_file, encoding="utf8") as f:
            mock_response = json.load(f)
        with open(data_path / "expected_output" / test_file, encoding="utf8") as f:
            expected_output = json.load(f)

        with mock.patch("ytmusicapi.YTMusic._send_request", return_value=mock_response):
            playlist = yt.get_playlist(playlist_id)
            assert playlist_id == playlist["id"]

            assert playlist == playlist | expected_output

            for thumbnail in playlist.get("thumbnails", []):
                assert thumbnail["url"] and thumbnail["width"] and thumbnail["height"]

            assert len(playlist["tracks"]) > 0
            for track in playlist["tracks"]:
                assert isinstance(track["title"], str) and track["title"]

                assert len(track["artists"]) > 0
                for artist in track["artists"]:
                    assert isinstance(artist["name"], str) and artist["name"]

                if track["videoType"] == "MUSIC_VIDEO_TYPE_ATV":
                    assert isinstance(track["album"]["name"], str) and track["album"]["name"]

                if (vote_status := track["communityVoteStatus"]) is not None:
                    assert isinstance(vote_status["netVoteValue"], int)
                    assert vote_status["status"] in VoteStatus

    @pytest.mark.parametrize(
        "playlist_id, tracks_len, related_len",
        [
            ("RDCLAK5uy_nfjzC9YC1NVPPZHvdoAtKVBOILMDOuxOs", 200, 10),
            ("PLj4BSJLnVpNyIjbCWXWNAmybc97FXLlTk", 200, 0),  # no related tracks
            ("PL6bPxvf5dW5clc3y9wAoslzqUrmkZ5c-u", 1000, 10),  # very large
            ("PLf6FAPI9j8OOAwvsj_FdO5tyd0GcPLnkm", 200, 0),  # track duration > 1k hours
        ],
    )
    def test_get_playlist_foreign(self, yt_oauth, playlist_id, tracks_len, related_len):
        playlist = yt_oauth.get_playlist(playlist_id, limit=None, related=True)
        assert len(playlist["duration"]) > 5
        assert playlist["trackCount"] > tracks_len
        # serialize each track to detect duplicates
        assert len({json.dumps(track) for track in playlist["tracks"]}) > tracks_len
        assert len(playlist["related"]) == related_len
        assert "suggestions" not in playlist
        assert playlist["owned"] is False

    def test_get_large_audio_playlist(self, yt_oauth):
        album = yt_oauth.get_playlist("OLAK5uy_noLNRtYnrcRVVO9rOyGMx64XyjVSCz1YU", limit=500)
        assert len(album["tracks"]) == 456
        assert album["trackCount"] == 456

    @pytest.mark.parametrize(
        "playlist_id",
        [
            "OLAK5uy_nT1mL8aZvxqfIRFN9L8FgIzfvk6HUkd0I",  # Show
            "OLAK5uy_kIzblCjlA2EThP40umbI81GfLrDaOhp5s",  # Audiobook
        ],
    )
    def test_get_playlist_audiobook(self, yt, playlist_id):
        playlist = yt.get_playlist(playlist_id)
        assert all(
            track["album"]["id"] and track["album"]["name"] == playlist["title"]
            for track in playlist["tracks"]
        )

    def test_get_playlist_empty(self, yt_empty):
        with pytest.raises((YTMusicServerError, KeyError, IndexError)):
            yt_empty.get_playlist("PLABC")

    def test_get_playlist_no_track_count(self, yt_oauth):
        playlist = yt_oauth.get_playlist("RDATgXd-")
        assert playlist["trackCount"] is None  # playlist has no trackCount
        assert len(playlist["tracks"]) >= 100

    def test_get_playlist_author(self, yt):
        playlist = yt.get_playlist("PL9tY0BWXOZFu4vlBOzIOmvT6wjYb2jNiV")
        assert "artists" not in playlist  # shouldn't return the "artists" key from parse_song_runs
        assert playlist["author"] == {"name": "Vevo", "id": "UC2pmfLm7iq6Ov1UwYrWYkZA"}
        playlist = yt.get_playlist("RDCLAK5uy_l2pHac-aawJYLcesgTf67gaKU-B9ekk1o")
        assert playlist["author"] == {"name": "YouTube Music", "id": None}

    # sorted: SUPPORTED_LANGUAGES is a set, so its order varies with PYTHONHASHSEED and
    # xdist workers would each collect a different parametrization
    @pytest.mark.parametrize("language", sorted(SUPPORTED_LANGUAGES))
    def test_get_playlist_languages(self, language):
        yt = YTMusic(language=language)
        result = yt.get_playlist("PLj4BSJLnVpNyIjbCWXWNAmybc97FXLlTk")
        assert result["trackCount"] == 255

    @pytest.mark.xdist_group("playlist")
    def test_get_playlist_owned(self, config, yt_brand):
        playlist = yt_brand.get_playlist(config["playlists"]["own"], related=True, suggestions_limit=21)
        assert len(playlist["tracks"]) < 100
        assert len(playlist["suggestions"]) == 21
        assert len(playlist["related"]) == 10
        assert playlist["owned"] is True

    @pytest.mark.parametrize(
        "playlist_id, has_vote",
        [
            # Settings:
            # Title: "Playlist with votes"
            # Description: ""
            # Privacy: unlisted
            # Voting: Everyone
            # Collaboration: On
            # Allow new collaborators: Off
            # 2 videos with id: HDTvoFuHtN0, QD3vEctbWGg
            ("PLa90Y86mjW3fKMrV_EPZ2-WZH8a50ss-b", True),
            # Settings:
            # Title: "Playlist without votes"
            # Description: ""
            # Privacy: unlisted
            # Voting: Voting off
            # Collaboration: On
            # Allow new collaborators: Off
            # 2 videos with id: HDTvoFuHtN0, QD3vEctbWGg
            ("PLa90Y86mjW3d57WTbI8aBp6Cgx9MHOuHD", False),
        ],
    )
    def test_get_playlist_with_votes(self, yt_oauth: YTMusic, playlist_id: str, has_vote: bool):
        playlist = yt_oauth.get_playlist(playlist_id)
        tracks = playlist["tracks"]
        assert len(tracks) > 0

        if not has_vote:
            for track in tracks:
                assert track["communityVoteStatus"] is None

            return

        for track in tracks:
            assert (vote_status := track["communityVoteStatus"]) is not None
            assert isinstance(vote_status["netVoteValue"], int)
            assert vote_status["status"] in VoteStatus

    @pytest.mark.xdist_group("playlist")
    def test_edit_playlist(self, config, yt_brand):
        playlist = yt_brand.get_playlist(config["playlists"]["own"])
        response1 = yt_brand.edit_playlist(
            playlist["id"],
            title="",
            description="",
            privacyStatus="PRIVATE",
            moveItem=(
                playlist["tracks"][1]["setVideoId"],
                playlist["tracks"][0]["setVideoId"],
            ),
        )
        assert response1 == ResponseStatus.SUCCEEDED, "Playlist edit 1 failed"
        response2 = yt_brand.edit_playlist(
            playlist["id"],
            title=playlist["title"],
            description=playlist["description"],
            privacyStatus=playlist["privacy"],
            moveItem=(
                playlist["tracks"][0]["setVideoId"],
                playlist["tracks"][1]["setVideoId"],
            ),
        )
        assert response2 == ResponseStatus.SUCCEEDED, "Playlist edit 2 failed"
        response3 = yt_brand.edit_playlist(
            playlist["id"],
            title=playlist["title"],
            description=playlist["description"],
            privacyStatus=playlist["privacy"],
            moveItem=playlist["tracks"][0]["setVideoId"],
        )
        assert response3 == "STATUS_SUCCEEDED", "Playlist edit 3 failed"

    @pytest.mark.xdist_group("playlist")
    def test_edit_playlist_collaboration(self, yt_oauth, yt_brand):
        playlist_id = create_playlist(yt_oauth, "test collaboration", "", privacy_status="UNLISTED")

        try:
            response = retry_playlist_edit(
                lambda: yt_oauth.edit_playlist(
                    playlist_id, collaboration=True, sortOrder=PlaylistSortOrder.TOP_VOTED
                )
            )
            assert response["status"] == ResponseStatus.SUCCEEDED
            join_collaboration_token = response["joinCollaborationToken"]

            TRACK_COUNT = 101
            response = yt_oauth.add_playlist_items(
                playlist_id, ["lYBUbBu4W08"] * TRACK_COUNT, duplicates=True
            )
            assert response["status"] == ResponseStatus.SUCCEEDED, "Adding playlist items failed"

            time.sleep(15)  # wait for collaboration to be enabled
            assert (
                yt_brand.join_collaborative_playlist(playlist_id, join_collaboration_token)
                == ResponseStatus.SUCCEEDED
            )

            playlist = yt_oauth.get_playlist(playlist_id, limit=None)
            assert len(playlist["collaborators"]["avatars"]) == 2
            assert "author" not in playlist

            # we should have continuations for large vote-sorted playlists
            assert len(playlist["tracks"]) == TRACK_COUNT

            assert yt_oauth.edit_playlist(playlist_id, collaboration=False) == ResponseStatus.SUCCEEDED
            time.sleep(3)

            playlist = yt_oauth.get_playlist(playlist_id)
            assert "collaborators" not in playlist
            assert playlist["author"]
        finally:
            yt_oauth.delete_playlist(playlist_id)

    @pytest.mark.xdist_group("playlist")
    def test_edit_playlist_community_vote(self, yt_oauth: YTMusic):
        playlist_id = create_playlist(yt_oauth, "test edit community vote", "", privacy_status="UNLISTED")

        try:
            response = retry_playlist_edit(lambda: yt_oauth.edit_playlist(playlist_id, collaboration=True))
            assert isinstance(response, dict)
            # Enable collaboration so can test all 3 vote options.
            assert response["status"] == ResponseStatus.SUCCEEDED

            response = yt_oauth.edit_playlist(playlist_id, voteOption=PlaylistVoteEditOptions.OFF)
            assert response == ResponseStatus.SUCCEEDED

            response = yt_oauth.edit_playlist(
                playlist_id, voteOption=PlaylistVoteEditOptions.EVERYONE_CAN_VOTE
            )
            assert response == ResponseStatus.SUCCEEDED

            response = yt_oauth.edit_playlist(
                playlist_id, voteOption=PlaylistVoteEditOptions.COLLABORATORS_ONLY
            )
            assert response == ResponseStatus.SUCCEEDED

        finally:
            yt_oauth.delete_playlist(playlist_id)

    def test_create_playlist_invalid_title(self, yt_brand):
        with pytest.raises(YTMusicUserError, match="invalid characters"):
            yt_brand.create_playlist("test >", description="test")

    def test_create_playlist_gated(self, yt_brand):
        """YTM answers with a dialog instead of creating the playlist, e.g. after many creations"""
        mock_response = {
            "actions": [
                {
                    "showEngagementPanelEndpoint": {
                        "sourcePanelIdentifier": "PAfeature_enablement",
                        "identifier": {"tag": "PAfeature_enablement"},
                    }
                }
            ]
        }
        with (
            mock.patch("ytmusicapi.YTMusic._send_request", return_value=mock_response),
            pytest.raises(YTMusicGatedError, match="PAfeature_enablement"),
        ):
            yt_brand.create_playlist("test", description="test")

    @pytest.mark.xdist_group("playlist")
    def test_end2end(self, yt_brand, sample_video):
        playlist_id = create_playlist(
            yt_brand,
            "test",
            "test description",
            source_playlist="OLAK5uy_lGQfnMNGvYCRdDq9ZLzJV2BJL2aHQsz9Y",
        )
        retry_playlist_edit(lambda: yt_brand.edit_playlist(playlist_id, addToTop=True))
        response = yt_brand.add_playlist_items(
            playlist_id,
            [sample_video, sample_video],
            source_playlist="OLAK5uy_nvjTE32aFYdFN7HCyMv3cGqD3wqBb4Jow",
            duplicates=True,
        )
        assert response["status"] == ResponseStatus.SUCCEEDED, "Adding playlist item failed"
        assert len(response["playlistEditResults"]) > 0, "Adding playlist item failed"
        time.sleep(3)
        yt_brand.edit_playlist(playlist_id, addToTop=False)
        time.sleep(3)
        playlist = yt_brand.get_playlist(playlist_id, related=True)
        assert len(playlist["tracks"]) == 46, "Getting playlist items failed"
        response = yt_brand.remove_playlist_items(playlist_id, playlist["tracks"])
        assert response == ResponseStatus.SUCCEEDED, "Playlist item removal failed"
        yt_brand.delete_playlist(playlist_id)
